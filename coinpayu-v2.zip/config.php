<?

$useragent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0";
$token = "2c2b5423165bda3dd237c4c8fa502537ff830ba8";
$PHPSESSID = "PHPSESSID=6et6kh0c0vn866j2dguu1cp3vp";
$cfduid = "__cfduid=dc52265672bc0d4d53c4bb3ff26c8834f1571738535; PHPSESSID=6et6kh0c0vn866j2dguu1cp3vp";