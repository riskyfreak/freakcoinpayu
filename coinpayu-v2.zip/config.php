<?

$useragent = "xxxxxxx";
$token = "xxxxxxx";
$PHPSESSID = "PHPSESSID=xxxxxxx";
$cfduid = "__cfduid=xxxxxxxxx";